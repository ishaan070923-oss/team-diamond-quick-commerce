# Data Dictionary

## Main fields

- **Category Size (₹ Cr/month):** Monthly category size reported in the source.
- **YoY May 2026 (%):** Year-on-year growth reported for May 2026.
- **YoY May 2027 Projected (%):** Projection shown in the source report.
- **Market Share (%):** Brand/category share reported by the source.
- **YoY Change (pp):** Year-on-year percentage-point change where reported.
- **Peak Time:** Reported peak ordering time for the category.
- **ROAS:** Return on ad spend values reported by season.

## Important

Units and labels follow the source report. Where the source uses `₹K Cr`, `₹Cr`, percentages, percentage points or projections, those distinctions are retained in the workbook.
