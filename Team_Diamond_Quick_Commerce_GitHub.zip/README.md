# Team Diamond — Quick Commerce Analysis

## Project Overview

This project presents a structured analysis of India's digital commerce and quick-commerce ecosystem using the supplied **India Digital Commerce Pulse — June 2026 Edition** report.

The project organizes the report's published figures into an Excel workbook for easier analysis, visualization and presentation.

## Project Focus

- Digital commerce and quick-commerce market landscape
- Quick-commerce GMV and growth
- Platform/dark-store expansion
- Category-level performance
- Amazon vs Quick Commerce category mix
- Brand market shares
- Consumer ordering/consumption peaks
- Seasonal ROAS
- Category and brand-level snapshots

## Files

| File | Description |
|---|---|
| `Quick-Commerce-Analysis.xlsx` | Structured Excel workbook containing extracted/organized data and dashboard |
| `docs/Quick-Commerce-Analysis.pdf` | PDF report used as the basis of the analysis |

## Excel Workbook

The workbook contains:

- Dashboard
- Platform Landscape
- Platform Growth
- Dark Stores
- Category Leaderboard
- Summer Winners
- Ice Cream
- Ice Keywords
- Ice Brands
- Face Care Search
- Face Care Brands
- Consumption Peaks
- Seasonal ROAS
- Category Summary
- Brand Shares

## Selected Figures from the Source Report

- Overall digital commerce GMV: **₹800K Cr (2026E)**
- Quick-commerce GMV: **₹108K Cr**
- Quick-commerce projected YoY growth: **+40%**
- Combined dark stores: **5,026 (May 2026)**
- Quick-commerce share of total digital commerce: **~13.5%**

These figures are reproduced from the supplied source report and are not independently verified in this project.

## Tools

- Microsoft Excel
- GitHub
- PDF-based data structuring

## Data & Attribution

**Primary source:** *1DS — India Digital Commerce Pulse, June 2026 Edition.*

The PDF and Excel workbook are provided for academic/project presentation purposes. Source attribution in the original report has been retained.

## Team

**Team Diamond**

## Suggested GitHub Use

Upload the complete project folder to a GitHub repository. The repository can then be shared as the project link for an academic assignment or portfolio.
